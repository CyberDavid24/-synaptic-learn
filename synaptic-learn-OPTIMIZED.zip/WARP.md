# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

**Synaptic Learn** is a modern, professional education platform for Roblox development skills. It's a static website built with vanilla HTML, CSS, and JavaScript featuring glassmorphism design, interactive animations, and responsive layouts.

### Key Features
- Glassmorphism design with dark gradient backgrounds
- Interactive course catalog with 8 specialized Roblox development courses
- Advanced interactive testing environments (Code Sandbox, Auto-Grading, Live Preview, etc.)
- Smooth animations and scroll effects
- Mobile-responsive design with hamburger navigation
- Modern CSS Grid and Flexbox layouts

## Architecture

### Frontend Structure
This is a **client-side only** static website with no backend dependencies or build process required.

**Core Components:**
- **`index.html`** - Single-page application with semantic HTML5 structure
- **`assets/css/style.css`** - Comprehensive CSS with CSS custom properties (variables) and modern layout techniques
- **`assets/js/script.js`** - ES6+ JavaScript class-based architecture with performance optimizations

### CSS Architecture
- **CSS Custom Properties** - Centralized design system with color palette, typography, and spacing variables defined in `:root`
- **Glassmorphism Effects** - Backdrop-filter blur effects with semi-transparent backgrounds
- **Component-Based Styling** - Modular CSS classes for cards, buttons, navigation, and sections
- **Responsive Design** - Mobile-first approach with breakpoints at 768px and 480px

### JavaScript Architecture
- **Class-Based Organization** - Main `SynapticLearn` class encapsulates all functionality
- **Event-Driven** - Comprehensive event handling for scroll, click, keyboard, and resize events
- **Performance Optimized** - Throttled scroll handlers, Intersection Observer for animations, and lazy DOM queries
- **Animation System** - CSS-in-JS dynamic styles for complex interactions and mobile menu states

## Development Workflow

### Local Development
Since this is a static website, you can run it directly in a browser or use a simple HTTP server:

```bash
# Option 1: Direct file access
# Simply open index.html in your browser

# Option 2: Python HTTP server
python -m http.server 8000

# Option 3: Node.js serve utility
npx serve .

# Option 4: PHP built-in server  
php -S localhost:8000
```

### File Editing
- **HTML Changes**: Edit `index.html` directly for content updates
- **Styling**: Modify `assets/css/style.css` - use CSS custom properties in `:root` for global changes
- **Interactivity**: Update `assets/js/script.js` - main functionality is in the `SynapticLearn` class

### Testing Changes
- **Cross-browser Testing**: Test in Chrome, Firefox, Safari, and Edge
- **Mobile Testing**: Use browser dev tools or test on actual devices
- **Performance**: Check scroll performance and animation smoothness
- **Accessibility**: Verify keyboard navigation and focus states work correctly

## Key Code Patterns

### CSS Custom Properties Usage
```css
:root {
    --primary-blue: #3b82f6;
    --dark-blue: #1d4ed8;
    --card-bg: rgba(26, 26, 46, 0.6);
    --transition-smooth: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
```

### Glassmorphism Card Pattern
```css
.card {
    background: var(--card-bg);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: var(--border-radius);
}
```

### JavaScript Class Method Pattern
```javascript
// Event binding in constructor
constructor() {
    this.bindEvents();
    this.setupAnimations();
}

// Throttled scroll handling for performance
handleScroll() {
    // Performance-optimized scroll logic
}
```

## Design System

### Color Palette
- **Background**: Dark gradient from `#0a0a0a` to `#1a1a2e`
- **Primary**: Blue gradient `#3b82f6` to `#1d4ed8`
- **Text**: White `#ffffff` and gray `#a0a0a0`
- **Cards**: Semi-transparent `rgba(26, 26, 46, 0.6)`

### Typography
- **Font**: Inter from Google Fonts
- **Weights**: 300, 400, 500, 600, 700, 800
- **Responsive sizing**: Uses `clamp()` for fluid typography

### Spacing & Layout
- **Section Padding**: 100px vertical (60px on mobile)
- **Container Max Width**: 1200px
- **Border Radius**: 16px consistent across components
- **Grid Layouts**: Auto-fit columns with minimum widths

## Browser Support & Performance

### Supported Features
- CSS Grid and Flexbox
- CSS Custom Properties
- Backdrop Filter (glassmorphism)
- Intersection Observer API
- ES6+ JavaScript features

### Performance Considerations
- **Scroll Throttling**: Scroll event handlers are throttled for smooth performance
- **Intersection Observer**: Used for efficient scroll-triggered animations
- **CSS Hardware Acceleration**: Transform and opacity animations use GPU acceleration
- **Lazy Animation Loading**: Staggered animations prevent blocking the main thread

## Content Management

### Course Information
Course data is stored directly in HTML within the `#courses` section. Each course card includes:
- Course title and description
- Interactive features (testing badges)  
- Meta information (duration, lessons, difficulty)
- Enrollment button

### Contact Information
- **Support**: support@synapticindustries.org
- **Admin**: admin@synapticindustries.org

## Responsive Breakpoints
- **Desktop**: 1200px+ (full layout)
- **Tablet**: 768px-1199px (adapted grid layouts)
- **Mobile**: <768px (hamburger menu, stacked layouts)
- **Small Mobile**: <480px (reduced padding, simplified layouts)

## Interactive Features
- **Smooth Scrolling**: Navigation links scroll to sections with offset for fixed header
- **Mobile Menu**: Animated hamburger menu with backdrop blur
- **Hover Effects**: Cards lift and scale with subtle icon rotations
- **Scroll Animations**: Elements fade in as they enter viewport
- **Click Feedback**: Buttons show visual feedback with scale animations
- **Enrollment Notifications**: Temporary success messages appear for course enrollments