// Synaptic Learn - Interactive JavaScript
// Author: AI Assistant
// Description: Modern interactive features with smooth animations and responsive behavior

class SynapticLearn {
    constructor() {
        this.initializeComponents();
        this.bindEvents();
        this.setupAnimations();
        this.setupScrollEffects();
    }

    initializeComponents() {
        // Cache DOM elements for better performance
        this.navbar = document.querySelector('.navbar');
        this.navToggle = document.querySelector('.nav-toggle');
        this.navMenu = document.querySelector('.nav-menu');
        this.navLinks = document.querySelectorAll('.nav-link');
        this.heroSection = document.querySelector('.hero');
        this.courseCards = document.querySelectorAll('.course-card');
        this.testingCards = document.querySelectorAll('.testing-card');
        this.featureCards = document.querySelectorAll('.feature-card');
        this.ctaButton = document.querySelector('.cta-button');
        this.enrollButtons = document.querySelectorAll('.enroll-button');

        // Initialize mobile menu state
        this.isMobileMenuOpen = false;
        
        // Initialize scroll position tracking
        this.lastScrollY = window.scrollY;
        this.isScrollingDown = false;
    }

    bindEvents() {
        // Navbar scroll effects
        window.addEventListener('scroll', this.handleScroll.bind(this));
        
        // Mobile menu toggle
        if (this.navToggle) {
            this.navToggle.addEventListener('click', this.toggleMobileMenu.bind(this));
        }

        // Smooth scrolling for navigation links
        this.navLinks.forEach(link => {
            link.addEventListener('click', this.handleNavClick.bind(this));
        });

        // CTA button interactions
        if (this.ctaButton) {
            this.ctaButton.addEventListener('click', this.handleCTAClick.bind(this));
        }

        // Enroll button interactions
        this.enrollButtons.forEach(button => {
            button.addEventListener('click', this.handleEnrollClick.bind(this));
        });

        // Card hover effects
        this.setupCardEffects();

        // Window resize handler
        window.addEventListener('resize', this.handleResize.bind(this));

        // Keyboard navigation
        document.addEventListener('keydown', this.handleKeyboard.bind(this));

        // Intersection Observer for animations
        this.setupIntersectionObserver();
    }

    setupAnimations() {
        // Add animation classes to elements
        const elementsToAnimate = [
            ...document.querySelectorAll('.course-card'),
            ...document.querySelectorAll('.testing-card'),
            ...document.querySelectorAll('.feature-card'),
            ...document.querySelectorAll('.section-title'),
            ...document.querySelectorAll('.section-subtitle')
        ];

        elementsToAnimate.forEach(element => {
            element.classList.add('animate-on-scroll');
        });

        // Stagger animation delays for course cards
        this.courseCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
        });
    }

    setupScrollEffects() {
        // Parallax effect for hero section
        if (this.heroSection) {
            this.setupParallax();
        }

        // Navbar blur and transparency on scroll
        this.updateNavbarOnScroll();
    }

    handleScroll() {
        const currentScrollY = window.scrollY;
        this.isScrollingDown = currentScrollY > this.lastScrollY;
        this.lastScrollY = currentScrollY;

        // Update navbar
        this.updateNavbarOnScroll();

        // Handle parallax
        this.updateParallax();

        // Hide mobile menu on scroll
        if (this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    updateNavbarOnScroll() {
        if (!this.navbar) return;

        const scrolled = window.scrollY > 50;
        
        if (scrolled) {
            this.navbar.style.background = 'rgba(10, 10, 10, 0.95)';
            this.navbar.style.backdropFilter = 'blur(25px)';
            this.navbar.style.borderBottom = '1px solid rgba(59, 130, 246, 0.3)';
        } else {
            this.navbar.style.background = 'rgba(10, 10, 10, 0.8)';
            this.navbar.style.backdropFilter = 'blur(20px)';
            this.navbar.style.borderBottom = '1px solid rgba(59, 130, 246, 0.2)';
        }

        // Hide navbar when scrolling down, show when scrolling up
        if (window.innerWidth <= 768) {
            if (this.isScrollingDown && window.scrollY > 100) {
                this.navbar.style.transform = 'translateY(-100%)';
            } else {
                this.navbar.style.transform = 'translateY(0)';
            }
        }
    }

    setupParallax() {
        // Subtle parallax effect for hero section
        window.addEventListener('scroll', () => {
            if (!this.heroSection) return;
            
            const scrolled = window.pageYOffset;
            const parallax = scrolled * 0.5;
            
            this.heroSection.style.transform = `translateY(${parallax}px)`;
        });
    }

    updateParallax() {
        if (!this.heroSection) return;
        
        const scrolled = window.pageYOffset;
        const parallax = scrolled * 0.3;
        
        this.heroSection.style.transform = `translateY(${parallax}px)`;
    }

    toggleMobileMenu() {
        if (!this.navMenu || !this.navToggle) return;

        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.navMenu.classList.add('mobile-active');
        this.navToggle.innerHTML = '<i class="fas fa-times"></i>';
        document.body.style.overflow = 'hidden';
        
        // Animate menu items
        this.navLinks.forEach((link, index) => {
            setTimeout(() => {
                link.style.animation = 'slideInRight 0.3s ease forwards';
            }, index * 50);
        });
    }

    closeMobileMenu() {
        if (!this.isMobileMenuOpen) return;
        
        this.navMenu.classList.remove('mobile-active');
        this.navToggle.innerHTML = '<i class="fas fa-bars"></i>';
        document.body.style.overflow = '';
        this.isMobileMenuOpen = false;
        
        // Reset animations
        this.navLinks.forEach(link => {
            link.style.animation = '';
        });
    }

    handleNavClick(e) {
        e.preventDefault();
        
        const targetId = e.currentTarget.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            this.smoothScrollTo(targetElement);
        }

        // Close mobile menu if open
        if (this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }

        // Add active state animation
        this.animateNavClick(e.currentTarget);
    }

    animateNavClick(element) {
        element.style.transform = 'scale(0.95)';
        setTimeout(() => {
            element.style.transform = '';
        }, 150);
    }

    smoothScrollTo(element) {
        const navHeight = this.navbar ? this.navbar.offsetHeight : 0;
        const elementPosition = element.offsetTop - navHeight;
        
        window.scrollTo({
            top: elementPosition,
            behavior: 'smooth'
        });
    }

    handleCTAClick(e) {
        e.preventDefault();
        
        // Add click animation
        const button = e.currentTarget;
        this.addClickAnimation(button);
        
        // Scroll to courses section
        const coursesSection = document.querySelector('#courses');
        if (coursesSection) {
            setTimeout(() => {
                this.smoothScrollTo(coursesSection);
            }, 200);
        }
    }

    handleEnrollClick(e) {
        e.preventDefault();
        
        const button = e.currentTarget;
        const courseCard = button.closest('.course-card');
        const courseTitle = courseCard.querySelector('.course-title').textContent;
        
        // Add click animation
        this.addClickAnimation(button);
        
        // Show enrollment modal or redirect (placeholder)
        this.showEnrollmentFeedback(courseTitle);
    }

    addClickAnimation(element) {
        element.style.transform = 'scale(0.95)';
        element.style.transition = 'transform 0.1s ease';
        
        setTimeout(() => {
            element.style.transform = '';
            element.style.transition = '';
        }, 100);
    }

    showEnrollmentFeedback(courseTitle) {
        // Create and show a temporary notification
        const notification = document.createElement('div');
        notification.className = 'enrollment-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-check-circle"></i>
                <span>Interest registered for "${courseTitle}"!</span>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
            z-index: 10000;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    setupCardEffects() {
        // Enhanced hover effects for course cards
        this.courseCards.forEach(card => {
            this.setupCardHover(card);
        });

        this.testingCards.forEach(card => {
            this.setupCardHover(card);
        });

        this.featureCards.forEach(card => {
            this.setupCardHover(card);
        });
    }

    setupCardHover(card) {
        let isHovering = false;

        card.addEventListener('mouseenter', () => {
            if (isHovering) return;
            isHovering = true;
            
            this.animateCardHover(card, true);
        });

        card.addEventListener('mouseleave', () => {
            isHovering = false;
            this.animateCardHover(card, false);
        });

        // Touch support for mobile
        card.addEventListener('touchstart', () => {
            this.animateCardHover(card, true);
        });

        card.addEventListener('touchend', () => {
            setTimeout(() => {
                this.animateCardHover(card, false);
            }, 150);
        });
    }

    animateCardHover(card, isEntering) {
        const icon = card.querySelector('.course-icon, .testing-icon, .feature-icon');
        const badges = card.querySelectorAll('.feature-badge');
        
        if (isEntering) {
            card.style.transform = 'translateY(-8px)';
            if (icon) {
                icon.style.transform = 'scale(1.05) rotate(5deg)';
            }
            badges.forEach((badge, index) => {
                setTimeout(() => {
                    badge.style.transform = 'translateY(-2px)';
                }, index * 50);
            });
        } else {
            card.style.transform = '';
            if (icon) {
                icon.style.transform = '';
            }
            badges.forEach(badge => {
                badge.style.transform = '';
            });
        }
    }

    setupIntersectionObserver() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                    
                    // Stagger animations for cards in the same section
                    if (entry.target.classList.contains('course-card') || 
                        entry.target.classList.contains('testing-card') || 
                        entry.target.classList.contains('feature-card')) {
                        
                        const siblings = Array.from(entry.target.parentElement.children);
                        const index = siblings.indexOf(entry.target);
                        
                        setTimeout(() => {
                            entry.target.style.opacity = '1';
                            entry.target.style.transform = 'translateY(0)';
                        }, index * 100);
                    }
                }
            });
        }, observerOptions);

        // Observe all animated elements
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            observer.observe(el);
        });
    }

    handleResize() {
        // Close mobile menu on resize to desktop
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }

        // Reset navbar transform on resize
        if (this.navbar) {
            this.navbar.style.transform = 'translateY(0)';
        }
    }

    handleKeyboard(e) {
        // ESC key closes mobile menu
        if (e.key === 'Escape' && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }

        // Enter key on buttons
        if (e.key === 'Enter' && e.target.classList.contains('enroll-button')) {
            e.target.click();
        }
    }

    // Utility function to add CSS animations dynamically
    addDynamicStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(30px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(30px);
                }
            }

            .mobile-active {
                display: flex !important;
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: rgba(10, 10, 10, 0.98);
                backdrop-filter: blur(25px);
                padding: 20px;
                border-top: 1px solid rgba(59, 130, 246, 0.2);
                animation: slideDown 0.3s ease;
            }

            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .mobile-active .nav-link {
                padding: 10px 0;
                border-bottom: 1px solid rgba(59, 130, 246, 0.1);
            }

            .mobile-active .nav-link:last-child {
                border-bottom: none;
            }

            .enrollment-notification .notification-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }

            .enrollment-notification i {
                font-size: 1.2rem;
            }

            /* Loading states */
            .loading-state {
                position: relative;
                overflow: hidden;
            }

            .loading-state::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.2), transparent);
                animation: loadingShimmer 1.5s infinite;
            }

            @keyframes loadingShimmer {
                0% { left: -100%; }
                100% { left: 100%; }
            }

            /* Enhanced focus styles for accessibility */
            .nav-link:focus,
            .cta-button:focus,
            .enroll-button:focus {
                outline: 2px solid #3b82f6;
                outline-offset: 2px;
            }

            /* Smooth transitions for all interactive elements */
            .course-card, .testing-card, .feature-card {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .course-icon, .testing-icon, .feature-icon {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .feature-badge {
                transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            }
        `;
        
        document.head.appendChild(style);
    }

    // Performance optimization
    throttle(func, delay) {
        let timeoutId;
        let lastExecTime = 0;
        
        return function (...args) {
            const currentTime = Date.now();
            
            if (currentTime - lastExecTime > delay) {
                func.apply(this, args);
                lastExecTime = currentTime;
            } else {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => {
                    func.apply(this, args);
                    lastExecTime = Date.now();
                }, delay - (currentTime - lastExecTime));
            }
        };
    }

    // Initialize performance monitoring
    initPerformanceMonitoring() {
        if ('performance' in window) {
            window.addEventListener('load', () => {
                const perfData = performance.getEntriesByType('navigation')[0];
                console.log('Page Load Time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
            });
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new SynapticLearn();
    app.addDynamicStyles();
    app.initPerformanceMonitoring();
    
    // Add a subtle loading completion effect
    setTimeout(() => {
        document.body.style.opacity = '1';
        document.body.style.transition = 'opacity 0.3s ease';
    }, 100);
});

// Loading state management
window.addEventListener('load', () => {
    // Remove any loading classes
    document.querySelectorAll('.loading-state').forEach(el => {
        el.classList.remove('loading-state');
    });
    
    // Add loaded class to body for any CSS transitions
    document.body.classList.add('page-loaded');
});

// Export for potential use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SynapticLearn;
}